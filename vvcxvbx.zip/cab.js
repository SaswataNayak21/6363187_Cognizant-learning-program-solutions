// JavaScript for handling the cab booking form

document.getElementById('cabBookingForm').addEventListener('submit', function(e) {
    e.preventDefault();

    // Get form values
    const pickup = document.getElementById('pickup').value;
    const dropoff = document.getElementById('dropoff').value;
    const time = document.getElementById('time').value;
    const cabType = document.getElementById('cabType').value;

    // Display confirmation message
    const confirmationMessage = `
        <h3>Booking Confirmed!</h3>
        <p><strong>Pick-up Location:</strong> ${pickup}</p>
        <p><strong>Drop-off Location:</strong> ${dropoff}</p>
        <p><strong>Pick-up Time:</strong> ${new Date(time).toLocaleString()}</p>
        <p><strong>Cab Type:</strong> ${cabType.charAt(0).toUpperCase() + cabType.slice(1)}</p>
        <p>Thank you for choosing our service! You will receive a confirmation call shortly.</p>
    `;
    document.getElementById('confirmationMessage').innerHTML = confirmationMessage;

    // Clear form fields after submission
    document.getElementById('cabBookingForm').reset();
});
