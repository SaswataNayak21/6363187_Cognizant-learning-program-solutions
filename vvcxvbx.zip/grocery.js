// Cart functionality
let cart = [];
let cartTotal = 0;

document.querySelectorAll('.add-to-cart-btn').forEach(button => {
    button.addEventListener('click', function() {
        const item = this.getAttribute('data-item');
        const price = parseFloat(this.getAttribute('data-price'));
        addToCart(item, price);
    });
});

function addToCart(item, price) {
    cart.push({ item, price });
    cartTotal += price;
    updateCart();
}

function updateCart() {
    const cartItemsDiv = document.getElementById('cart-items');
    cartItemsDiv.innerHTML = '';
    
    cart.forEach((cartItem, index) => {
        const cartItemDiv = document.createElement('div');
        cartItemDiv.textContent = `${cartItem.item} - $${cartItem.price.toFixed(2)}`;
        cartItemsDiv.appendChild(cartItemDiv);
    });

    document.getElementById('cart-total').textContent = cartTotal.toFixed(2);
}

// Order form submission
document.getElementById('orderForm').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Order placed successfully!');
    cart = [];
    cartTotal = 0;
    updateCart();
    this.reset();
});
