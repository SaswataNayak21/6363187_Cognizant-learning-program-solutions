document.addEventListener("DOMContentLoaded", () => {
    const contactForm = document.getElementById('contactForm');

    contactForm.addEventListener('submit', async (e) => {
        e.preventDefault(); // Prevent the form from submitting in the traditional way
        
        // Collect form data
        const formData = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            message: document.getElementById('message').value
        };

        try {
            // Send data to the backend using Fetch API
            const response = await fetch('/submit-contact', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                // Handle success - you could show a message to the user
                const result = await response.json();
                alert(result.message || 'Form submitted successfully!');
                contactForm.reset(); // Clear the form after successful submission
            } else {
                // Handle errors - notify the user
                const error = await response.json();
                alert(error.error || 'Something went wrong, please try again.');
            }
        } catch (err) {
            console.error('Error submitting the form:', err);
            alert('There was an error submitting the form. Please try again later.');
        }
    });
});

// javascript part when we click on buttons for more services 
// Wait until the DOM is fully loaded
document.addEventListener("DOMContentLoaded", function() {
    // Get the button and the extra details section
    const moreDetailsBtn = document.getElementById('moreDetailsBtn');
    const extraDetails = document.getElementById('extraDetails');

    // Add an event listener to the "See More Details" button
    moreDetailsBtn.addEventListener('click', function() {
        // Toggle the display of the extra details
        if (extraDetails.style.display === "none") {
            extraDetails.style.display = "block";  // Show extra details
            moreDetailsBtn.textContent = "Show Less Details"; // Change button text
        } else {
            extraDetails.style.display = "none";  // Hide extra details
            moreDetailsBtn.textContent = "See More Details"; // Revert button text
        }
    });
});
/////////////////////////////////////////////////////////////////////////////////////////////
// Toggle "More Details" section
document.getElementById("moreMentalHealthDetailsBtn").addEventListener("click", function() {
    var extraDetails = document.getElementById("extraMentalHealthDetails");
    if (extraDetails.style.display === "none" || extraDetails.style.display === "") {
        extraDetails.style.display = "block";
        this.textContent = "See Less Details";
    } else {
        extraDetails.style.display = "none";
        this.textContent = "See More Details";
    }
});

// JavaScript to handle "See More Details" button click
document.getElementById("moreMentalHealthDetailsBtn").addEventListener("click", function() {
    // Get the hidden section
    var extraDetails = document.getElementById("extraMentalHealthDetails");

    // Toggle visibility
    if (extraDetails.style.display === "none") {
        extraDetails.style.display = "block"; // Show the hidden details
        this.textContent = "See Less Details"; // Change button text
    } else {
        extraDetails.style.display = "none"; // Hide the details again
        this.textContent = "See More Details"; // Change button text back
    }
});
// Toggle "More Details" section
document.getElementById("moreMentalHealthDetailsBtn").addEventListener("click", function() {
    var extraDetails = document.getElementById("extraMentalHealthDetails");
    if (extraDetails.style.display === "none") {
        extraDetails.style.display = "block";
        this.textContent = "See Less Details";
    } else {
        extraDetails.style.display = "none";
        this.textContent = "See More Details";
    }
});

// Toggle "Book a Counseling Session" form
document.getElementById("bookCounselingBtn").addEventListener("click", function() {
    var bookForm = document.getElementById("bookCounselingForm");
    if (bookForm.style.display === "none") {
        bookForm.style.display = "block";
        this.textContent = "Cancel Booking";
    } else {
        bookForm.style.display = "none";
        this.textContent = "Book a Counseling Session";
    }
});

// Handle form submission
document.getElementById("bookingForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent page reload

    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var date = document.getElementById("date").value;
    var time = document.getElementById("time").value;

    alert(`Thank you, ${name}! Your counseling session has been booked for ${date} at ${time}. A confirmation email has been sent to ${email}.`);

    // Hide the form after submission
    document.getElementById("bookCounselingForm").style.display = "none";
    document.getElementById("bookCounselingBtn").textContent = "Book a Counseling Session";
});
// ///////////////////////////////////////////////////////////
// vaccination 
// JavaScript code to confirm booking
document.addEventListener("DOMContentLoaded", function() {
    // Get the vaccination form
    const vaccinationForm = document.getElementById("vaccinationForm");

    // Add submit event listener to the form
    vaccinationForm.addEventListener("submit", function(event) {
        // Prevent the form from actually submitting
        event.preventDefault();

        // Get selected values from the form
        const ageGroup = document.getElementById("ageGroup").value;
        const vaccine = document.getElementById("vaccine").value;
        const date = document.getElementById("appointmentDate").value;
        const time = document.getElementById("appointmentTime").value;

        // Check if all fields are filled out
        if (ageGroup && vaccine && date && time) {
            // Display confirmation alert
            alert(`Your booking is confirmed!\n\nDetails:\nAge Group: ${ageGroup}\nVaccine: ${vaccine}\nDate: ${date}\nTime: ${time}`);
        } else {
            // Display alert for missing fields
            alert("Please fill out all fields to book your slot.");
        }
    });
});
