// JavaScript code to confirm booking
document.addEventListener("DOMContentLoaded", function() {
    // Get the vaccination form
    const vaccinationForm = document.getElementById("vaccinationForm");

    // Add submit event listener to the form
    vaccinationForm.addEventListener("submit", function(event) {
        // Prevent the form from actually submitting
        event.preventDefault();

        // Get selected values from the form
        const ageGroup = document.getElementById("ageGroup").value;
        const vaccine = document.getElementById("vaccine").value;
        const date = document.getElementById("appointmentDate").value;
        const time = document.getElementById("appointmentTime").value;

        // Check if all fields are filled out
        if (ageGroup && vaccine && date && time) {
            // Display confirmation alert
            alert(`Your booking is confirmed!\n\nDetails:\nAge Group: ${ageGroup}\nVaccine: ${vaccine}\nDate: ${date}\nTime: ${time}`);
        } else {
            // Display alert for missing fields
            alert("Please fill out all fields to book your slot.");
        }
    });
});
